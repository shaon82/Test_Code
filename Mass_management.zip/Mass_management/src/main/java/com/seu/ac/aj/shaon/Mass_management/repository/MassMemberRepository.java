package com.seu.ac.aj.shaon.Mass_management.repository;

import com.seu.ac.aj.shaon.Mass_management.model.MassMember;
import com.seu.ac.aj.shaon.Mass_management.model.Name;
import org.springframework.data.repository.CrudRepository;

import java.util.Optional;

public interface MassMemberRepository extends CrudRepository<MassMember, Long> {
    Optional<MassMember> findByName(Name name);
}

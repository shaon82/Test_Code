package com.seu.ac.aj.shaon.Mass_management.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.ToString;

import javax.persistence.Embeddable;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;
import java.util.Objects;

@Data
@ToString
@Embeddable
public class PermanentAddress {
    @Id
    @NotNull
    private String UP;
    @NotNull
    private String homeDistrict;
    @NotNull
    private String village;

    public PermanentAddress(@NotNull String UP, @NotNull String homeDistrict, @NotNull String village) {
        this.UP = UP;
        this.homeDistrict = homeDistrict;
        this.village = village;
    }

    public String getUP() {
        return UP;
    }

    public void setUP(String UP) {
        this.UP = UP;
    }

    public String getHomeDistrict() {
        return homeDistrict;
    }

    public void setHomeDistrict(String homeDistrict) {
        this.homeDistrict = homeDistrict;
    }

    public String getVillage() {
        return village;
    }

    public void setVillage(String village) {
        this.village = village;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PermanentAddress that = (PermanentAddress) o;
        return Objects.equals(UP, that.UP) &&
                Objects.equals(homeDistrict, that.homeDistrict) &&
                Objects.equals(village, that.village);
    }

    @Override
    public int hashCode() {

        return Objects.hash(UP, homeDistrict, village);
    }
}

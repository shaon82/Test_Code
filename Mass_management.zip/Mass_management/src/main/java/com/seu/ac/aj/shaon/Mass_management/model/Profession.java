package com.seu.ac.aj.shaon.Mass_management.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.ToString;

import javax.persistence.Embeddable;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;
import java.util.Objects;

@Data
@AllArgsConstructor
@ToString
@Embeddable
public class Profession {
    @Id
    @NotNull
    private String professionName;

    public Profession(@NotNull String professionName) {
        this.professionName = professionName;
    }

    public String getProfessionName() {
        return professionName;
    }

    public void setProfessionName(String professionName) {
        this.professionName = professionName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Profession that = (Profession) o;
        return Objects.equals(professionName, that.professionName);
    }

    @Override
    public int hashCode() {

        return Objects.hash(professionName);
    }
}

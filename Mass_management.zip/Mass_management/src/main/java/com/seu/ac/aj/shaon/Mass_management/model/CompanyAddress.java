package com.seu.ac.aj.shaon.Mass_management.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.ToString;

import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import java.util.Objects;

@Data
@ToString
@Embeddable
public class CompanyAddress {
    @NotNull
    private String streetNumber;
    @NotNull
    private String streetName;
    @NotNull
    private String city;
    @NotNull
    private String province;
    @NotNull
    private String postalCode;

    public CompanyAddress(@NotNull String streetNumber, @NotNull String streetName, @NotNull String city, @NotNull String province, @NotNull String postalCode) {
        this.streetNumber = streetNumber;
        this.streetName = streetName;
        this.city = city;
        this.province = province;
        this.postalCode = postalCode;
    }

    public String getStreetNumber() {
        return streetNumber;
    }

    public void setStreetNumber(String streetNumber) {
        this.streetNumber = streetNumber;
    }

    public String getStreetName() {
        return streetName;
    }

    public void setStreetName(String streetName) {
        this.streetName = streetName;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CompanyAddress that = (CompanyAddress) o;
        return Objects.equals(streetNumber, that.streetNumber) &&
                Objects.equals(streetName, that.streetName) &&
                Objects.equals(city, that.city) &&
                Objects.equals(province, that.province) &&
                Objects.equals(postalCode, that.postalCode);
    }

    @Override
    public int hashCode() {

        return Objects.hash(streetNumber, streetName, city, province, postalCode);
    }
}

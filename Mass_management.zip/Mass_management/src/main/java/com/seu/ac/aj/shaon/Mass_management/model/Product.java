package com.seu.ac.aj.shaon.Mass_management.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "product")
@ToString
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "productId")
    @NotNull
    private long productId;
    @Column(name = "productName")
    @NotNull
    private String productName;
    @Column(name = "productPrice")
    @NotNull
    private double productPrice;
    @Column(name = "productquantity")
    @NotNull
    private double productQuantity;

}

package com.seu.ac.aj.shaon.Mass_management.controller;

import com.seu.ac.aj.shaon.Mass_management.model.Product;
import com.seu.ac.aj.shaon.Mass_management.service.ProductServicec;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.Optional;

@RestController
public class ProductController {
    @Autowired
    private ProductServicec productServicec;


    @PostMapping(value = "/addproduct")
    public void addProduct(@RequestBody Product product){
        productServicec.addProduct(product);
    }

    @DeleteMapping("/deleteproduct")
    public void deleteProduct(@RequestBody Product product){
        productServicec.deleteProduct(product);
    }
}

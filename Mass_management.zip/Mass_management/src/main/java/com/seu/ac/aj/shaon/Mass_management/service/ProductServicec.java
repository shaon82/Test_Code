package com.seu.ac.aj.shaon.Mass_management.service;

import com.seu.ac.aj.shaon.Mass_management.model.Product;
import com.seu.ac.aj.shaon.Mass_management.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Optional;

public class ProductServicec {
    @Autowired
    private ProductRepository productRepository;

    public void addProduct(Product product) {
        productRepository.save(product);
    }

    public void deleteProduct(Product product) {
        productRepository.delete(product);
    }
}

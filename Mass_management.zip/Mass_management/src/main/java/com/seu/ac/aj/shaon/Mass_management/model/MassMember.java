package com.seu.ac.aj.shaon.Mass_management.model;



import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.Objects;

@Data
@Entity
@Table(name = "Member_info")
public class MassMember {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @NotNull
    private long id;
    @NotNull
    @Embedded
    private Name name;
    @NotNull
    @Embedded
    private ContactInformation contactInformation;
    @NotNull
    @Enumerated
    private Gender gender;
    @NotNull
    @Embedded
    private PermanentAddress permanentAddress;
    @NotNull
    @Embedded
    private Profession profession;
    @NotNull
    @Embedded
    private CompanyName companyName;
    @NotNull
    @Embedded
    private CompanyAddress companyAddress;

    public MassMember() {

    }

    public MassMember(@NotNull long id, @NotNull Name name, @NotNull ContactInformation contactInformation, @NotNull Gender gender, @NotNull PermanentAddress permanentAddress, @NotNull Profession profession, @NotNull CompanyName companyName, @NotNull CompanyAddress companyAddress) {
        this.id = id;
        this.name = name;
        this.contactInformation = contactInformation;
        this.gender = gender;
        this.permanentAddress = permanentAddress;
        this.profession = profession;
        this.companyName = companyName;
        this.companyAddress = companyAddress;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Name getName() {
        return name;
    }

    public void setName(Name name) {
        this.name = name;
    }

    public ContactInformation getContactInformation() {
        return contactInformation;
    }

    public void setContactInformation(ContactInformation contactInformation) {
        this.contactInformation = contactInformation;
    }

    public Gender getGender() {
        return gender;
    }

    public void setGender(Gender gender) {
        this.gender = gender;
    }

    public PermanentAddress getPermanentAddress() {
        return permanentAddress;
    }

    public void setPermanentAddress(PermanentAddress permanentAddress) {
        this.permanentAddress = permanentAddress;
    }

    public Profession getProfession() {
        return profession;
    }

    public void setProfession(Profession profession) {
        this.profession = profession;
    }

    public CompanyName getCompanyName() {
        return companyName;
    }

    public void setCompanyName(CompanyName companyName) {
        this.companyName = companyName;
    }

    public CompanyAddress getCompanyAddress() {
        return companyAddress;
    }

    public void setCompanyAddress(CompanyAddress companyAddress) {
        this.companyAddress = companyAddress;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        MassMember that = (MassMember) o;
        return id == that.id &&
                Objects.equals(name, that.name) &&
                Objects.equals(contactInformation, that.contactInformation) &&
                gender == that.gender &&
                Objects.equals(permanentAddress, that.permanentAddress) &&
                Objects.equals(profession, that.profession) &&
                Objects.equals(companyName, that.companyName) &&
                Objects.equals(companyAddress, that.companyAddress);
    }

    @Override
    public int hashCode() {

        return Objects.hash(id, name, contactInformation, gender, permanentAddress, profession, companyName, companyAddress);
    }
}

package com.seu.ac.aj.shaon.Mass_management.model;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.ToString;

import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import java.util.Objects;

@Data
@ToString
@Embeddable
public class Name {
    @NotNull
    private String fristName;
    @NotNull
    private String middleName;
    @NotNull
    private String lastName;

    public Name(@NotNull String fristName, @NotNull String middleName, @NotNull String lastName) {
        this.fristName = fristName;
        this.middleName = middleName;
        this.lastName = lastName;
    }

    public String getFristName() {
        return fristName;
    }

    public void setFristName(String fristName) {
        this.fristName = fristName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Name name = (Name) o;
        return Objects.equals(fristName, name.fristName) &&
                Objects.equals(middleName, name.middleName) &&
                Objects.equals(lastName, name.lastName);
    }

    @Override
    public int hashCode() {

        return Objects.hash(fristName, middleName, lastName);
    }
}

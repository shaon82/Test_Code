package com.seu.ac.aj.shaon.Mass_management.controller;

import com.seu.ac.aj.shaon.Mass_management.model.MassMember;
import com.seu.ac.aj.shaon.Mass_management.model.Name;
import com.seu.ac.aj.shaon.Mass_management.service.MassMemberService;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
public class MassMemberController {
    private MassMemberService massMemberService;


    @GetMapping(value = "/allmember")
    @ResponseBody
    public Iterable<MassMember>getallMember(){
        return massMemberService.getAllMember();
    }


    @GetMapping(value = "/allmember/{id}")
    @ResponseBody
    public Optional<MassMember>getOneMember(@RequestParam long id){
        return massMemberService.getOneMember(id);
    }

    @PostMapping(value = "/addmember")
    @ResponseBody
    public MassMember addMember(@RequestBody MassMember massMember){
        return massMemberService.save(massMember);
    }

    @DeleteMapping(value = "/delete/{id}")
    public void deleteMember(@PathVariable long id){
        massMemberService.deleteMember(id);
    }
    @PutMapping(value = "/member/{id}")
    @ResponseBody
    public MassMember replaceMember(@RequestBody MassMember massMember, @PathVariable long id){
        return massMemberService.replaceMember(massMember, id);
    }

    @GetMapping(value = "/allmember/{name}")
    @ResponseBody
    public Optional<MassMember>getOneMemberByName(@RequestParam Name name){
        return massMemberService.getOneMemberByName(name);
    }
}

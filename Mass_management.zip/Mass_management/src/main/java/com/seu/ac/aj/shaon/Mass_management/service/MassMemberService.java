package com.seu.ac.aj.shaon.Mass_management.service;

import com.seu.ac.aj.shaon.Mass_management.model.MassMember;
import com.seu.ac.aj.shaon.Mass_management.model.Name;
import com.seu.ac.aj.shaon.Mass_management.repository.MassMemberRepository;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class MassMemberService {
    private MassMemberRepository massMemberRepository;

    public Iterable<MassMember> getAllMember() {
        return massMemberRepository.findAll();
    }

    public Optional<MassMember> getOneMember(long id) {
        return massMemberRepository.findById(id);
    }

    public MassMember save(MassMember massMember) {
        return massMemberRepository.save(massMember);
    }


    public void deleteMember(long id) {
        massMemberRepository.deleteById(id);
    }

    public MassMember replaceMember(MassMember massMember, long id) {
        return massMemberRepository.findById(id).map(massMember1 -> {
            massMember1.setId(new MassMember().getId());
            massMember1.setName(new MassMember().getName());
            massMember1.setContactInformation(new MassMember().getContactInformation());
            massMember1.setGender(new MassMember().getGender());
            massMember1.setPermanentAddress(new MassMember().getPermanentAddress());
            massMember1.setProfession(new MassMember().getProfession());
            massMember1.setCompanyName(new MassMember().getCompanyName());
            massMember1.setCompanyAddress(new MassMember().getCompanyAddress());
            return massMemberRepository.save(massMember);
        })
                .orElseGet(() -> {
                    new MassMember().setId(id);
                    return massMemberRepository.save(new MassMember());
                });
    }

    public Optional<MassMember> getOneMemberByName(Name name) {
        return massMemberRepository.findByName(name);
    }
}


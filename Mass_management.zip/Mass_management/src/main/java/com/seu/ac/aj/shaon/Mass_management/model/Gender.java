package com.seu.ac.aj.shaon.Mass_management.model;

public enum Gender {

   MALE,
    FEMALE;
}
